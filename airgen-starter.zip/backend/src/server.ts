import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import jwt from "@fastify/jwt";
import { analyzeRequirement } from "@airgen/req-qa";
import { z } from "zod";

const app = Fastify({ logger: true });

await app.register(cors, { origin: true });
await app.register(helmet);
await app.register(rateLimit, { max: 100, timeWindow: "1 minute" });
await app.register(jwt, { secret: process.env.API_JWT_SECRET || "dev_secret" });

app.get("/health", async () => ({ ok: true }));

app.post("/qa", async (req, reply) => {
  const schema = z.object({ text: z.string().min(1) });
  const body = schema.parse(req.body);
  const result = analyzeRequirement(body.text);
  return result;
});

app.post("/draft", async (req, reply) => {
  // Stub drafts (LLM gateway left to implement)
  return {
    items: [
      {
        pattern: "event",
        verification: "Test",
        text: "When brake pedal force exceeds 50 N, the vehicle control unit shall command hydraulic pressure to achieve ≥ 6 m/s² deceleration within 250 ms."
      },
      {
        pattern: "ubiquitous",
        verification: "Analysis",
        text: "The braking subsystem shall provide diagnostic trouble codes within 100 ms of detecting a sensor fault."
      }
    ]
  };
});

app.post("/apply-fix", async (req, reply) => {
  // Minimal edit suggestion: replace 'sufficient' with explicit metric if present
  const schema = z.object({ text: z.string().min(1) });
  const { text } = schema.parse(req.body);
  const fixed = text.replace(/\bsufficient\b/gi, "≥ [SPECIFY]");
  return { before: text, after: fixed, note: "Replaced ambiguous 'sufficient' with placeholder metric." };
});

app.post("/link/suggest", async (req, reply) => {
  // Stub: returns empty suggestions to be replaced by embeddings/pgvector
  return { suggestions: [] };
});

app.post("/baseline", async (req, reply) => {
  // Stub baseline response
  return { ok: true, baseline: { id: "BL-0001", createdAt: new Date().toISOString() } };
});

const port = Number(process.env.API_PORT || 8787);
app.listen({ port, host: "0.0.0.0" }).catch((e) => {
  app.log.error(e);
  process.exit(1);
});
