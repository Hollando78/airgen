export const AMBIGUOUS = [
  "fast","user-friendly","easy","optimal","adequate","minimal","appropriate","acceptable",
  "maximize","minimize","robust","state-of-the-art","sufficient","as soon as possible",
  "graceful","intuitive","seamless","significant","efficient","quickly"
];
