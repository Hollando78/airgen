---
id: RISK-BRK-OVER-01
type: risk
title: Overrun due to latency
severity: high
---

Excessive command-to-pressure latency could cause extended stopping distances.
