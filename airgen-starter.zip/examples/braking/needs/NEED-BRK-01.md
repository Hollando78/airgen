---
id: NEED-BRK-01
type: need
title: Stop safely when requested
---

Operators require the vehicle to stop safely and predictably upon brake pedal application.
