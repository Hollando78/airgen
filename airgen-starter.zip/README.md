# AIRGen Starter Kit (SaaS on VPS)

A minimal, **ship-ready starter** for AIRGen — AI-powered Requirements Generation with a deterministic heuristics engine, Markdown-first storage, Mermaid diagrams, and a multi-tenant SaaS backend.

## What’s inside
- **pnpm workspaces**: `packages/req-qa` (heuristics engine) + `backend` (Fastify API)
- **Deterministic QA**: TypeScript rules that score and lint requirements (ISO/IEC/IEEE 29148 + EARS-inspired)
- **Examples**: A small braking subsystem with requirements, needs, risks, tests, and Mermaid diagrams
- **Docker Compose**: Postgres, Redis, API (Fastify), and Traefik reverse proxy
- **Export-friendly Markdown layout** ready to mirror to Git
- **RBAC placeholders**, **multitenancy-ready DB schema**, and **baseline hooks**

## Quick start (local, with Docker)
```bash
# 1) Copy env and tweak as needed
cp .env.example .env

# 2) Start services
docker compose up -d --build

# 3) API is available behind Traefik at:
# http://localhost/api/health
```

## Quick start (dev mode without Docker)
```bash
# Requires Node 20+ and pnpm
pnpm install
pnpm -C packages/req-qa build
pnpm -C backend dev
# API runs at http://localhost:8787
```

## Workspace layout
```
airgen-starter/
├─ packages/
│  └─ req-qa/              # Deterministic requirement QA (rules + scorer)
├─ backend/                # Fastify API that wraps the rules + LLM stubs
├─ examples/               # Example project with Markdown artifacts + Mermaid
├─ docker-compose.yml      # Postgres, Redis, API, Traefik
├─ .env.example            # Default env vars
└─ README.md
```

## API sketch
- `GET /health` → healthcheck
- `POST /draft` → (stub) returns EARS-patterned draft examples
- `POST /qa` → run deterministic QA on a requirement
- `POST /apply-fix` → apply minimal-edit fix proposal
- `POST /link/suggest` → (stub) embedding/heuristic suggestions
- `POST /baseline` → (stub) prepare baseline metadata

## Notes
- The LLM gateway is intentionally stubbed — swap your preferred provider later.
- The **req-qa** package is pure and testable. It **does not** call any LLM.
- Keep Markdown as the **source of truth**. Use the DB for indices/metadata.
- Mermaid is supported as plain `.mmd` files; render in your frontend of choice.
